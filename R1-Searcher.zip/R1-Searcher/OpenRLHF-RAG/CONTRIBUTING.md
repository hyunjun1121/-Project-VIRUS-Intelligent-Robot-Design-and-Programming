# Contributing to OpenRLHF

After cloning the repository, please install pre-commit hooks with:
```
pip install pre-commit
pre-commit install
```