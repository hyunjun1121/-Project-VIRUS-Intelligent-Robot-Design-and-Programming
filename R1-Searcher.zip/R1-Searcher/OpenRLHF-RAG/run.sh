bash /home/songhuatong/OpenRLHF/dpsk1_5b-1node-grpo-jjh_1.sh | tee /home/songhuatong/RAG_RL/results/log/dpsk1_5b-1node-grpo-jjh-log_1
sleep 360

bash /home/songhuatong/OpenRLHF/dpsk1_5b-1node-grpo-jjh_2.sh | tee /home/songhuatong/RAG_RL/results/log/dpsk1_5b-1node-grpo-jjh-log_2