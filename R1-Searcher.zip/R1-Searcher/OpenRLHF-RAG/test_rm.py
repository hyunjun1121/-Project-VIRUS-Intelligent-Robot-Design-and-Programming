import requests

url=""
response = requests.post(url=url, json=data, headers=headers, timeout=360)