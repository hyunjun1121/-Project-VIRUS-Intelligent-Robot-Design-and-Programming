python /home/songhuatong/Reason-Searcher/evaluation/eval_search_loacl.py --gpu_id 5 --temp 0.0 --port 5006 --prompt_type v0 --src_file xxx  --model_path xxx

python /home/songhuatong/Reason-Searcher/evaluation/eval_search_web.py --gpu_id 1 --temp 0.0 --port 5004 --prompt_type v0 --src_file xxx --model_path xxx